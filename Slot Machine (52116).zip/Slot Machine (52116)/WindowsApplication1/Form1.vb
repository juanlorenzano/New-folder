﻿Public Class Form1

    Public pictureArray() As String = {"apple.jpg", "cherry.png", "greenstrawberry.png", "strawberry.png"}
    Public amount As Double = 0


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim n1 As Integer = 0
        Dim n2 As Integer = 0
        Dim n3 As Integer = 0
        Dim r1 As New Random
        n1 = r1.Next(0, 4)
        n2 = r1.Next(0, 4)
        n3 = r1.Next(0, 4)

        PictureBox1.Image = Image.FromFile(pictureArray(n1))
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage

        PictureBox2.Image = Image.FromFile(pictureArray(n2))
        PictureBox2.SizeMode = PictureBoxSizeMode.StretchImage

        PictureBox3.Image = Image.FromFile(pictureArray(n3))
        PictureBox3.SizeMode = PictureBoxSizeMode.StretchImage
        'Button1.Enabled = False

        Dim results As IO.StreamWriter
        results = IO.File.AppendText("scores.txt")
        results.Write(n1)
        results.Write(n2)
        results.Write(n3)
        'System.IO.File.WriteAllText("scores.txt", "")
        results.Close()

        Dim readScores As String
        readScores = My.Computer.FileSystem.ReadAllText("scores.txt")
        MsgBox(readScores)
        'My.Computer.FileSystem.DeleteFile("scores.txt")

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles Me.Load
        TabControl1.TabPages(1).Enabled = False
        Dim lines() As String = IO.File.ReadAllLines("usernamePassword.txt")
        ListBox1.Items.AddRange(lines)
    End Sub

    Private Sub signButton_Click(sender As Object, e As EventArgs) Handles signButton.Click
        ' Find the string in ListBox2.
        Dim index As Integer = ListBox1.FindString(usernameBox.Text.ToString)
        ' If the item was not found in ListBox 2 display a message box, otherwise select it in ListBox2.
        If index = -1 Then
            MessageBox.Show("No username exists in database, try again.")
            usernameBox.Clear()
            passwordBox.Clear()
        Else
            If ListBox1.Items(index + 1) <> passwordBox.Text Then
                MessageBox.Show("Wrong Password, try again.")
                passwordBox.Clear()
            Else
                amount = Convert.ToDouble(ListBox1.Items(index + 2))
                TabControl1.SelectedTab = TabPage2
                TabControl1.TabPages(1).Enabled = True
                TabControl1.TabPages(0).Enabled = False
                Label6.Text = amount
            End If
        End If
    End Sub

    Private Sub RegisterButton_Click(sender As Object, e As EventArgs) Handles RegisterButton.Click
        Dim results As IO.StreamWriter
        results = IO.File.AppendText("usernamePassword.txt")
        results.WriteLine(Environment.NewLine + usernameBox.Text)
        ListBox1.Items.Add(usernameBox.Text)
        results.WriteLine(passwordBox.Text)
        ListBox1.Items.Add(passwordBox.Text)
        results.WriteLine("500")
        ListBox1.Items.Add("500")
        results.Close()
        MessageBox.Show("Please sign in using your new login information.")
        usernameBox.Clear()
        passwordBox.Clear()

    End Sub
End Class
