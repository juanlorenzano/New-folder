﻿Public Class Form1

    Public pictureArray() As String = {"bulbasaur.png", "squirtle.png", "charmander.png", "pikachu.png", "bulbasaur.gif", "squirtle.gif", "charmander.gif", "pikachu.gif", "chikorita.png", "totodile.png", "cyndaquil.png", "pichu.png", "chikorita.gif", "totodile.gif", "cyndaquil.gif", "pichu.gif"}
    Public amount As Double = 0
    Public userIndex As Integer = 0
    Public bet As Double = 0
    Public arrayTranslation = 0

    Sub PlayLoopingBackgroundSoundFile()
        My.Computer.Audio.Play("background.wav",
        AudioPlayMode.BackgroundLoop)
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles spinButton.Click

        spinButton.Enabled = False
        Dim n1 As Integer = 0
        Dim n2 As Integer = 0
        Dim n3 As Integer = 0

        Dim p1 As Double = 0
        Dim p2 As Double = 0
        Dim p3 As Double = 0

        Dim r1 As New Random
        n1 = r1.Next(0, 1000)
        n2 = r1.Next(0, 1000)
        n3 = r1.Next(0, 1000)

        p1 = n1 / 1000
        p2 = n2 / 1000
        p3 = n3 / 1000

        If p1 < 0.1 Then
            n1 = 3
        ElseIf p1 < 0.3 Then
            n1 = 2
        ElseIf p1 < 0.6 Then
            n1 = 1
        ElseIf p1 <= 1 Then
            n1 = 0
        End If

        If p2 < 0.1 Then
            n2 = 3
        ElseIf p2 < 0.3 Then
            n2 = 2
        ElseIf p2 < 0.6 Then
            n2 = 1
        ElseIf p2 <= 1 Then
            n2 = 0
        End If

        If p3 < 0.1 Then
            n3 = 3
        ElseIf p3 < 0.3 Then
            n3 = 2
        ElseIf p3 < 0.6 Then
            n3 = 1
        ElseIf p3 <= 1 Then
            n3 = 0
        End If



        PictureBox1.Image = Image.FromFile(pictureArray(n1 + arrayTranslation))
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage

        PictureBox2.Image = Image.FromFile(pictureArray(n2 + arrayTranslation))
        PictureBox2.SizeMode = PictureBoxSizeMode.StretchImage

        PictureBox3.Image = Image.FromFile(pictureArray(n3 + arrayTranslation))
        PictureBox3.SizeMode = PictureBoxSizeMode.StretchImage

        If n1 + arrayTranslation = n2 + arrayTranslation AndAlso n3 + arrayTranslation = n2 + arrayTranslation Then
            If n1 = 3 Then
                amount += (bet * 1.1)
                MessageBox.Show("Congratulations! You won " & (bet * 1.1))
            ElseIf n1 = 2 Then
                amount += (bet * 1.3)
                MessageBox.Show("Congratulations! You won " & (bet * 1.3))
            ElseIf n1 = 1 Then
                amount += (bet * 1.6)
                MessageBox.Show("Congratulations! You won " & (bet * 1.6))
            ElseIf n1 = 0 Then
                amount += (bet * 2)
                MessageBox.Show("Congratulations! You won " & (bet * 2))
            End If
            Label6.Text = amount
        Else
            MessageBox.Show("Sorry you lost this turn, take another bet.")
            Label6.Text = amount
        End If


    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles Me.Load
        TabControl1.TabPages(1).Enabled = False
        Dim lines() As String = IO.File.ReadAllLines("usernamePassword.txt")
        ListBox1.Items.AddRange(lines)

        Dim paymentMessage As String = "Credit card availability to be installed after this beta is over," & Environment.NewLine & " for the moment you can just add to your account without paying."

        Label9.Text = paymentMessage.PadRight(150, "-") & Environment.NewLine & "Thanks for your patience."

    End Sub

    Private Sub signButton_Click(sender As Object, e As EventArgs) Handles signButton.Click
        ' Find the string in ListBox2.
        Dim index As Integer = ListBox1.FindString(usernameBox.Text.ToString)
        ' If the item was not found in ListBox 2 display a message box, otherwise select it in ListBox2.
        If index = -1 Then
            MessageBox.Show("No username exists in database, try again.")
            usernameBox.Clear()
            passwordBox.Clear()
        Else
            If ListBox1.Items(index + 1) <> passwordBox.Text Then
                MessageBox.Show("Wrong Password, try again.")
                passwordBox.Clear()
            Else
                userIndex = index
                amount = Convert.ToDouble(ListBox1.Items(index + 2))
                TabControl1.SelectedTab = TabPage2
                TabControl1.TabPages(1).Enabled = True
                TabControl1.TabPages(0).Enabled = False
                Label6.Text = amount
                PlayLoopingBackgroundSoundFile()

            End If
        End If
    End Sub

    Private Sub RegisterButton_Click(sender As Object, e As EventArgs) Handles RegisterButton.Click
        Dim results As IO.StreamWriter
        results = IO.File.AppendText("usernamePassword.txt")
        results.WriteLine(Environment.NewLine + usernameBox.Text)
        ListBox1.Items.Add(usernameBox.Text)
        results.WriteLine(passwordBox.Text)
        ListBox1.Items.Add(passwordBox.Text)
        results.WriteLine("500")
        ListBox1.Items.Add("500")
        results.Close()
        MessageBox.Show("Please sign in using your new login information.")
        usernameBox.Clear()
        passwordBox.Clear()

    End Sub

    Private Sub betButton_Click(sender As Object, e As EventArgs) Handles betButton.Click
        If Convert.ToDouble(InsertMoney.Text) > amount Then
            MessageBox.Show("You don't have enough money in your account for that! Try a smaller amount.")
        Else
            bet = Convert.ToDouble(InsertMoney.Text)
            amount -= bet
            spinButton.Enabled = True
            Label6.Text = amount
        End If
    End Sub

    Private Sub settingsButton_Click(sender As Object, e As EventArgs) Handles settingsButton.Click
        If RadioButton1.Checked = True AndAlso CheckBox2.Checked = False Then
            arrayTranslation = 0
        ElseIf RadioButton1.Checked = True AndAlso CheckBox2.Checked = True Then
            arrayTranslation = 4
        ElseIf RadioButton2.Checked = True AndAlso CheckBox2.Checked = False Then
            arrayTranslation = 8
        ElseIf RadioButton2.Checked = True AndAlso CheckBox2.Checked = True Then
            arrayTranslation = 12
        End If

        If CheckBox1.Checked = False Then
            My.Computer.Audio.Stop()
        Else
            PlayLoopingBackgroundSoundFile()
        End If


    End Sub
End Class
