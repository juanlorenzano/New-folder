﻿Public Class Form1

    Public pictureArray() As String = {"apple.jpg", "cherry.png", "greenstrawberry.png", "strawberry.png"}
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim n1 As Integer = 0
        Dim n2 As Integer = 0
        Dim n3 As Integer = 0
        Dim r1 As New Random
        n1 = r1.Next(0, 4)
        n2 = r1.Next(0, 4)
        n3 = r1.Next(0, 4)

        PictureBox1.Image = Image.FromFile(pictureArray(n1))
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage

        PictureBox2.Image = Image.FromFile(pictureArray(n2))
        PictureBox2.SizeMode = PictureBoxSizeMode.StretchImage

        PictureBox3.Image = Image.FromFile(pictureArray(n3))
        PictureBox3.SizeMode = PictureBoxSizeMode.StretchImage
        'Button1.Enabled = False

        Dim results As IO.StreamWriter
        results = IO.File.AppendText("scores.txt")
        results.Write(n1)
        results.Write(n2)
        results.Write(n3)
        'System.IO.File.WriteAllText("scores.txt", "")
        results.Close()

        Dim readScores As String
        readScores = My.Computer.FileSystem.ReadAllText("scores.txt")
        MsgBox(readScores)
        My.Computer.FileSystem.DeleteFile("scores.txt")

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

    End Sub
End Class
