﻿Public Class Form1

    Public pictureArray() As String = {"bulbasaur.png", "squirtle.png", "charmander.png", "pikachu.png", "bulbasaur.gif", "squirtle.gif", "charmander.gif", "pikachu.gif", "chikorita.png", "totodile.png", "cyndaquil.png", "pichu.png", "chikorita.gif", "totodile.gif", "cyndaquil.gif", "pichu.gif"}
    Public amount As Double = 0
    Public userIndex As Integer = 0
    Public bet As Double = 0
    Public arrayTranslation = 0
    Public signedIn As Boolean = False

    Sub PlayLoopingBackgroundSoundFile()
        My.Computer.Audio.Play("background.wav",
        AudioPlayMode.BackgroundLoop)
    End Sub

    Function SearchUsername(ByVal word As String, ByVal start As Integer) As Integer
        Dim index As Integer = -1
        Dim count As Integer = ListBox1.Items.Count - 1
        Dim username As String = ""
        Dim a As Integer = start
        For a = start To count Step 3
            username = ListBox1.Items.Item(a)
            If word = username Then
                index = a
                Exit For
            ElseIf word <> username Then
                index = -1
            End If
        Next
        a = index
        Return a
    End Function

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles spinButton.Click

        spinButton.Enabled = False
        Dim n1 As Integer = 0
        Dim n2 As Integer = 0
        Dim n3 As Integer = 0

        Dim p1 As Double = 0
        Dim p2 As Double = 0
        Dim p3 As Double = 0

        Dim r1 As New Random
        n1 = r1.Next(0, 1000)
        n2 = r1.Next(0, 1000)
        n3 = r1.Next(0, 1000)

        p1 = n1 / 1000
        p2 = n2 / 1000
        p3 = n3 / 1000

        If p1 < 0.1 Then
            n1 = 3
        ElseIf p1 < 0.3 Then
            n1 = 2
        ElseIf p1 < 0.6 Then
            n1 = 1
        ElseIf p1 <= 1 Then
            n1 = 0
        End If

        If p2 < 0.1 Then
            n2 = 3
        ElseIf p2 < 0.3 Then
            n2 = 2
        ElseIf p2 < 0.6 Then
            n2 = 1
        ElseIf p2 <= 1 Then
            n2 = 0
        End If

        If p3 < 0.1 Then
            n3 = 3
        ElseIf p3 < 0.3 Then
            n3 = 2
        ElseIf p3 < 0.6 Then
            n3 = 1
        ElseIf p3 <= 1 Then
            n3 = 0
        End If



        PictureBox1.Image = Image.FromFile(pictureArray(n1 + arrayTranslation))
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage

        PictureBox2.Image = Image.FromFile(pictureArray(n2 + arrayTranslation))
        PictureBox2.SizeMode = PictureBoxSizeMode.StretchImage

        PictureBox3.Image = Image.FromFile(pictureArray(n3 + arrayTranslation))
        PictureBox3.SizeMode = PictureBoxSizeMode.StretchImage

        If n1 + arrayTranslation = n2 + arrayTranslation AndAlso n3 + arrayTranslation = n2 + arrayTranslation Then
            If n1 = 3 Then
                amount += (bet * 1.1)
                MessageBox.Show("Congratulations! You won " & (bet * 1.1))
            ElseIf n1 = 2 Then
                amount += (bet * 1.3)
                MessageBox.Show("Congratulations! You won " & (bet * 1.3))
            ElseIf n1 = 1 Then
                amount += (bet * 1.6)
                MessageBox.Show("Congratulations! You won " & (bet * 1.6))
            ElseIf n1 = 0 Then
                amount += (bet * 2)
                MessageBox.Show("Congratulations! You won " & (bet * 2))
            End If
            Label6.Text = amount
        Else
            MessageBox.Show("Sorry you lost this turn, take another bet.")
            Label6.Text = amount
        End If
        betButton.Enabled = True
        exitAccountButton.Enabled = True


    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles Me.Load
        TabControl1.TabPages(1).Enabled = False
        TabControl1.TabPages(2).Enabled = False
        TabControl1.TabPages(3).Enabled = False
        Dim lines() As String = IO.File.ReadAllLines("usernamePassword.txt")
        ListBox1.Items.AddRange(lines)

        Dim paymentMessage As String = "Credit card availability to be installed after this beta is over," & Environment.NewLine & " for the moment you can just add to your account without paying."

        Label9.Text = paymentMessage.PadRight(150, "-") & Environment.NewLine & "Thanks for your patience."

        IO.File.WriteAllText("usernamePassword.txt", "")

    End Sub

    Private Sub signButton_Click(sender As Object, e As EventArgs) Handles signButton.Click

        Label6.Visible = True
        Dim index As Integer = 0
        index = SearchUsername(usernameBox.Text, 0)
        If index = -1 Then
            MessageBox.Show("No username exists, try again.")
            usernameBox.Clear()
            passwordBox.Clear()
        Else
            If ListBox1.Items(index + 1) <> passwordBox.Text Then
                MessageBox.Show("Wrong Password, try again.")
                passwordBox.Clear()
            Else
                signedIn = True
                userIndex = index
                amount = Convert.ToDouble(ListBox1.Items(index + 2))
                TabControl1.SelectedTab = TabPage2
                TabControl1.TabPages(1).Enabled = True
                TabControl1.TabPages(2).Enabled = True
                TabControl1.TabPages(3).Enabled = True

                TabControl1.TabPages(0).Enabled = False
                Label6.Text = amount
            End If
        End If
    End Sub

    Private Sub RegisterButton_Click(sender As Object, e As EventArgs) Handles RegisterButton.Click
        If SearchUsername(usernameBox.Text, 0) = -1 Then
            ListBox1.Items.Add(usernameBox.Text)
            ListBox1.Items.Add(passwordBox.Text)
            ListBox1.Items.Add("500")
            MessageBox.Show("Please sign in using your new login information.")
            usernameBox.Clear()
            passwordBox.Clear()
        Else
            MessageBox.Show("Username not available, try a different one.")
            usernameBox.Clear()
            passwordBox.Clear()

        End If
    End Sub

    Private Sub betButton_Click(sender As Object, e As EventArgs) Handles betButton.Click
        If InsertMoney.Text = String.Empty Then
            MessageBox.Show("Please input a value.")
            InsertMoney.Clear()
        ElseIf IsNumeric(InsertMoney.Text) = False Then
            MessageBox.Show("Please put a numeric input.")
            InsertMoney.Clear()
        ElseIf Convert.ToDouble(InsertMoney.Text) <= 0 OrElse Convert.ToDouble(InsertMoney.Text) > amount Then
            MessageBox.Show("Please put an amount bigger than 0.")
            InsertMoney.Clear()
        ElseIf Convert.ToDouble(InsertMoney.Text) > amount Then
            MessageBox.Show("Please put a smaller amount.")
            InsertMoney.Clear()
        Else
            bet = Convert.ToDouble(InsertMoney.Text)
            amount -= bet
            spinButton.Enabled = True
            Label6.Text = amount
            betButton.Enabled = False
            InsertMoney.Clear()
            exitAccountButton.Enabled = False
        End If
    End Sub

    Private Sub settingsButton_Click(sender As Object, e As EventArgs) Handles settingsButton.Click
        If RadioButton1.Checked = True AndAlso CheckBox2.Checked = False Then
            arrayTranslation = 0
        ElseIf RadioButton1.Checked = True AndAlso CheckBox2.Checked = True Then
            arrayTranslation = 4
        ElseIf RadioButton2.Checked = True AndAlso CheckBox2.Checked = False Then
            arrayTranslation = 8
        ElseIf RadioButton2.Checked = True AndAlso CheckBox2.Checked = True Then
            arrayTranslation = 12
        End If

        If CheckBox1.Checked = False Then
            My.Computer.Audio.Stop()
        Else
            PlayLoopingBackgroundSoundFile()
        End If

        TabControl1.SelectedTab = TabPage2
    End Sub

    Private Sub confirmButton_Click(sender As Object, e As EventArgs) Handles confirmButton.Click
        If addMoneyBox.Text = String.Empty Then
            MessageBox.Show("Please input a value.")
            addMoneyBox.Clear()
        ElseIf IsNumeric(addMoneyBox.Text) = False Then
            MessageBox.Show("Please put a numeric value.")
            addMoneyBox.Clear()
        ElseIf Convert.ToDouble(addMoneyBox.Text) <= 0 Then
            MessageBox.Show("Please put amount bigger than 0.")
            addMoneyBox.Clear()
        Else
            amount += Convert.ToDouble(addMoneyBox.Text)
            Label6.Text = amount
            addMoneyBox.Clear()
        End If
    End Sub

    Private Sub exitAccountButton_Click(sender As Object, e As EventArgs) Handles exitAccountButton.Click
        ListBox1.Items(userIndex + 2) = amount
        TabControl1.SelectedTab = TabPage1
        usernameBox.Clear()
        passwordBox.Clear()
        Label6.Visible = False
        addMoneyBox.Clear()
        PictureBox1.Image = Nothing
        PictureBox2.Image = Nothing
        PictureBox3.Image = Nothing
        TabControl1.TabPages(0).Enabled = True
        TabControl1.TabPages(1).Enabled = False
        TabControl1.TabPages(2).Enabled = False
        TabControl1.TabPages(3).Enabled = False
        My.Computer.Audio.Stop()
        RadioButton1.Checked = False
        RadioButton2.Checked = False
        CheckBox1.Checked = False
        CheckBox2.Checked = False
    End Sub

    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        If signedIn = True Then
            ListBox1.Items(userIndex + 2) = amount
        End If
        Dim file As System.IO.StreamWriter
        file = My.Computer.FileSystem.OpenTextFileWriter("usernamePassword.txt", True)
        For Each i As String In ListBox1.Items
            file.WriteLine(i)
        Next
        file.Close()

    End Sub
End Class
